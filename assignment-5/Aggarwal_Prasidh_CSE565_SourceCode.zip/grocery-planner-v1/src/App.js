import React, { useState } from "react";
import GroceryStore from "./GroceryStore";
import CartBuilder from "./CartBuilder";
import FinalReview from "./FinalReview";

function App() {
  const [page, setPage] = useState(1);
  const [travelDetails, setTravelDetails] = useState({
    destination: "",
    dietPreferences: [],
    budget: 0,
    deliveryType: "",
  });

  const handleNextFromDestination = (destinationDetails) => {
    setTravelDetails({ ...travelDetails, ...destinationDetails });
    setPage(2);
  };

  const handleNextFromItinerary = (cartItems, deliveryType) => {
    setTravelDetails({
      ...travelDetails,
      dietPreferences: cartItems,
      deliveryType: deliveryType,
    });
    setPage(3);
  };

  const handleBack = () => setPage(page - 1);
  const handleConfirmBooking = () => alert("Booking Confirmed!"); // Replace with actual booking logic

  return (
    <div>
      {page === 1 && <GroceryStore onNext={handleNextFromDestination} />}
      {page === 2 && (
        <CartBuilder
          selectedDestination={travelDetails.destination}
          onBack={handleBack}
          onNext={handleNextFromItinerary}
        />
      )}
      {page === 3 && (
        <FinalReview
          itineraryDetails={travelDetails}
          onBack={handleBack}
          onConfirm={handleConfirmBooking}
        />
      )}
    </div>
  );
}

export default App;
