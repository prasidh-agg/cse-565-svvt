import React, { useState } from "react";

function CartBuilder({ onBack, onNext, selectedDestination }) {
  const [cartItems, setCartItems] = useState(["Apple", "Tomatoes"]);
  const [newItem, setNewItem] = useState("");
  const [deliveryType, setDeliveryType] = useState("pickup");

  const addNewItem = () => {
    if (newItem) {
      setCartItems([...cartItems, newItem]);
      setNewItem("");
    }
  };

  const handleDeliveryTypeChange = (event) => {
    setDeliveryType(event.target.value);
  };

  return (
    <div>
      <h1>Build Your Shopping Cart for {selectedDestination}</h1>

      <div>
        <h3>Select Mode:</h3>
        <label>
          <input
            type="radio"
            value="delivery"
            checked={deliveryType === "delivery"}
            onChange={handleDeliveryTypeChange}
          />
          Delivery
        </label>
        <label>
          <input
            type="radio"
            value="pickup"
            id="pickup-radio-button"
            checked={deliveryType === "pickup"}
            onChange={handleDeliveryTypeChange}
          />
          Pickup
        </label>
      </div>

      <img src="/cart.jpeg" alt="Itinerary" height={500} />
      <div>
        <label>
          Add Item:
          <input
            type="text"
            id="add-item-input"
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
          />
        </label>
        <button onClick={addNewItem}>Add</button>
      </div>

      <ul>
        {cartItems.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>

      <button onClick={onBack}>Change Grocery Store</button>
      <button
        onClick={() => onNext(cartItems, deliveryType)}
        id="next-button-itinerary"
      >
        Review Payment
      </button>
    </div>
  );
}

export default CartBuilder;
