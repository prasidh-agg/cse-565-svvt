import React, { useState } from "react";

function GroceryStore({ onNext }) {
  const [destination, setGroceryStore] = useState("");
  const [dietPreferences, setDietPreferences] = useState({
    vegan: true,
    vegetarian: true,
    nonvegetarian: false
  });
  const [budget, setBudget] = useState(50);

  const handleActivityChange = (event) => {
    setDietPreferences({
      ...dietPreferences,
      [event.target.name]: event.target.checked,
    });
  };

  const handleBudgetChange = (event) => {
    setBudget(event.target.value);
  };

  return (
    <div>
      <h1>Select a Grocery store</h1>
      <img src="/grocery-store.jpeg" alt="Destination" height={500} />
      <p></p>
      <label>
        Grocery Store:
        <input
          type="text"
          id="grocery-store-input"
          value={destination}
          onChange={(e) => setGroceryStore(e.target.value)}
          style={{ width: "250px" }} // Set the width to 250px
        />
      </label>

      <div style={{ display: "flex", flexDirection: "column"}}>
        <label>
          Vegan
          <input
            type="checkbox"
            name="vegan"
            id="vegan-checkbox"
            checked={dietPreferences.vegan}
            onChange={handleActivityChange}
          />
        </label>
        <label>
          Vegetarian
          <input
            type="checkbox"
            name="vegetarian"
            id="vegetarian-checkbox"
            checked={dietPreferences.vegetarian}
            onChange={handleActivityChange}
          />
        </label>
        <label>
          Non-Vegetarian
          <input
            type="checkbox"
            name="nonvegetarian"
            id="nonvegetarian-checkbox"
            checked={dietPreferences.nonvegetarian}
            onChange={handleActivityChange}
          />
        </label>
      </div>

      <div>
        <label>
          Budget: ${budget}
          <input
            type="range"
            min="0"
            max="100"
            value={budget}
            onChange={handleBudgetChange}
          />
        </label>
      </div>

      <button
        onClick={() => onNext({ destination, dietPreferences, budget })}
        id="next-button-destination"
      >
        Next
      </button>
    </div>
  );
}

export default GroceryStore;
