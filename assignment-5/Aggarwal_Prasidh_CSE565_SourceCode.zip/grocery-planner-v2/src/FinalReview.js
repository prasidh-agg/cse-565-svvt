import React, { useState } from "react";

function FinalReview({ onBack, onConfirm, itineraryDetails }) {
  const [satisfaction, setSatisfaction] = useState(5);
  const [documentDelivery, setDocumentDelivery] = useState("email");

  const [personalInfo, setPersonalInfo] = useState({
    name: "",
    email: "",
    phone: "",
  });
  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
  });

  const handlePersonalInfoChange = (event) => {
    setPersonalInfo({
      ...personalInfo,
      [event.target.name]: event.target.value,
    });
  };

  const handlePaymentInfoChange = (event) => {
    setPaymentInfo({
      ...paymentInfo,
      [event.target.name]: event.target.value,
    });
  };

  const handleConfirm = () => {
    onConfirm();
  };

  return (
    <div>
      
      <div style={{display: "flex", flexDirection: "column"}}>
        <h2>Enter Your Personal details</h2>
        <label>
          Name:
          <input
            type="text"
            name="name"
            id="name-input"
            value={personalInfo.name}
            onChange={handlePersonalInfoChange}
          />
        </label>
        <label>
          Email:
          <input
            type="email"
            name="email"
            value={personalInfo.email}
            onChange={handlePersonalInfoChange}
          />
        </label>
        <label>
          Phone:
          <input
            type="tel"
            name="phone"
            value={personalInfo.phone}
            onChange={handlePersonalInfoChange}
          />
        </label>
      </div>

      <div>
        <h2>Review and Confirm</h2>
        <img src="/tjs.jpeg" alt="Final Review" height={300} />
      </div>

      <div style={{display: "flex", flexDirection: "column"}}>
        <h2>Your Order details: </h2>
        <p><strong>Selected Grocery Store: {itineraryDetails.destination}</strong></p>
        <p><strong>Selected Items:</strong></p>
        <ul>
          {itineraryDetails.dietPreferences.map((activity, index) => (
            <li key={index}>{activity}</li>
          ))}
        </ul>
        <p><strong>Mode of Delivery: {itineraryDetails.deliveryType}</strong></p>
      </div>

      <div>
        <h3>Preferred Method of Statement Delivery:</h3>
        <label>
          <input
            type="radio"
            value="email"
            checked={documentDelivery === "email"}
            onChange={(e) => setDocumentDelivery(e.target.value)}
          />
          Email
        </label>
        <label>
          <input
            type="radio"
            id="postal-radio-button"
            value="postal"
            checked={documentDelivery === "postal"}
            onChange={(e) => setDocumentDelivery(e.target.value)}
          />
          Postal Mail
        </label>
      </div>

      <div style={{display: "flex", flexDirection: "column"}}>
        <h2>Payment Information</h2>
        <label>
          Card Number:
          <input
            type="text"
            name="cardNumber"
            value={paymentInfo.cardNumber}
            onChange={handlePaymentInfoChange}
          />
        </label>
        <label>
          Expiry Date:
          <input
            type="text"
            name="expiryDate"
            value={paymentInfo.expiryDate}
            onChange={handlePaymentInfoChange}
          />
        </label>
        <label>
          CVV:
          <input
            type="text"
            name="cvv"
            value={paymentInfo.cvv}
            onChange={handlePaymentInfoChange}
          />
        </label>
      </div>

      <div>
        <label>
          Satisfaction Rating: {satisfaction}
          <input
            type="range"
            min="1"
            max="10"
            value={satisfaction}
            onChange={(e) => setSatisfaction(e.target.value)}
          />
        </label>
      </div>

      <p></p>
      <button onClick={onBack}>Back</button>
      <button onClick={handleConfirm}>Confirm payment</button>
    </div>
  );
}

export default FinalReview;
